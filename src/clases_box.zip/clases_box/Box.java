package clases_box;

public class Box {
    private double lenght;
    private double width;
    private double height;

    public Box(double lenght, double width, double height) {
        this.lenght = lenght;
        this.width = width;
        this.height = height;
    }

    public double getLenght() {
        return lenght;
    }

    public double getWidth() {
        return width;
    }

    public double getHeight() {
        return height;
    }
    public double surface(){
        return (2 * this.lenght * this.width)+(2 * this.lenght * this.height)
                + (2 * this.width * this.height);
    }
    public double lateral() {
        return (2 * this.lenght * this.height) + (2 * this.width * this.height);
    }
    public double volume (){
        return this.lenght * this.width * this.height;
    }
}
